#__init__.py
from .minivggnet import MiniVGGNet


